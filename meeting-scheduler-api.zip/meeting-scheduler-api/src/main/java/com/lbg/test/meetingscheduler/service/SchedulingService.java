package com.lbg.test.meetingscheduler.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface SchedulingService {

	Map<LocalDate, List<String>> processPayload(String payload);
}
