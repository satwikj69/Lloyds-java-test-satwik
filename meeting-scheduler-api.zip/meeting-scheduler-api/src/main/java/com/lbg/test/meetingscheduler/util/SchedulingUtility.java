package com.lbg.test.meetingscheduler.util;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.lbg.test.meetingscheduler.model.MeetingFormat;

import lombok.NonNull;

public class SchedulingUtility {

	private static LocalTime officeStartTime;
	private static LocalTime officeEndTime;

	/**
	 * Uses the input array to populate the POJO for further manipulation.
	 * 
	 * @param data
	 * @return
	 */
	public static List<MeetingFormat> populateDto(String[] data) {
		List<MeetingFormat> meetings = new ArrayList<MeetingFormat>();
		setOfficeHours(data[0]);
		for (int i = 1; i < data.length; i++) {
			String[] dtoValues = data[i].split(" ");
			MeetingFormat meeting = new MeetingFormat();
			meeting.setSubmissionDate(LocalDate.parse(dtoValues[0], DateTimeFormatter.ISO_LOCAL_DATE));
			meeting.setSubmissionTime(LocalTime.parse(dtoValues[1], DateTimeFormatter.ISO_LOCAL_TIME));
			meeting.setEmpId(dtoValues[2]);
			meeting.setStartDate(LocalDate.parse(dtoValues[3], DateTimeFormatter.ISO_LOCAL_DATE));
			meeting.setStartTime(LocalTime.parse(dtoValues[4], DateTimeFormatter.ISO_LOCAL_TIME));
			meeting.setEndTime(meeting.getStartTime().plusHours(Integer.parseInt(dtoValues[5])));
			if (validateBooking(meeting)) {
				meetings.add(meeting);
			}
		}
		return meetings;
	}

	/**
	 * Groups the meetings based on their startDate.
	 * 
	 * @param bookings
	 * @return
	 */
	public static Map<LocalDate, List<String>> groupMeetings(List<MeetingFormat> meetings) {
		return meetings.stream().collect(Collectors.groupingBy(MeetingFormat::getStartDate,
				Collectors.mapping(MeetingFormat::getDetails, Collectors.toList())));
	}

	private static void setOfficeHours(String window) {
		String[] duration = window.split(" ");
		officeStartTime = LocalTime.parse(duration[0], DateTimeFormatter.ofPattern("HHMM"));
		officeEndTime = LocalTime.parse(duration[1], DateTimeFormatter.ofPattern("HHMM"));
	}

	/**
	 * Validate if the meeting lies within the office-hours.
	 * 
	 * @param meeting
	 * @return
	 */
	private static boolean validateBooking(MeetingFormat meeting) {
		if (meeting.getStartTime().compareTo(officeStartTime) < 0
				|| meeting.getEndTime().compareTo(officeEndTime) > 0) {
			return false;
		}
		return true;
	}

	/**
	 * Removes overlapped meetings for an employee.
	 * 
	 * @param meetings
	 */
	public static void removeOverlappedMeetings(List<MeetingFormat> meetings) {
		Map<LocalDate, List<MeetingFormat>> groupedMeetings = meetings.stream()
				.collect(Collectors.groupingBy(MeetingFormat::getStartDate));
		Iterator<Map.Entry<LocalDate, List<MeetingFormat>>> itr = groupedMeetings.entrySet().iterator();
		while (itr.hasNext()) {
			Map.Entry<LocalDate, List<MeetingFormat>> entry = itr.next();
			Iterator<MeetingFormat> meetingItr = entry.getValue().iterator();
			LocalTime startTime = null;
			LocalTime endTime = null;
			String employeeId = null;
			while (meetingItr.hasNext()) {
				// compare startTime and EndTime for meetings
				if (null == startTime && null == endTime) {
					startTime = meetingItr.next().getStartTime();
					endTime = meetingItr.next().getEndTime();
					employeeId = meetingItr.next().getEmpId();
					// compare EmpID before removing a meeting.
				} else if (meetingItr.next().getEmpId().equalsIgnoreCase(employeeId)) {
					if (startTime.isBefore(meetingItr.next().getEndTime())
							&& endTime.isAfter(meetingItr.next().getStartTime())) {
						meetingItr.remove();
					}
				}
			}
		}
	}

}
