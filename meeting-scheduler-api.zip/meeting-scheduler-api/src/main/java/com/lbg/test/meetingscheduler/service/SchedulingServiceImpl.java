package com.lbg.test.meetingscheduler.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lbg.test.meetingscheduler.util.SchedulingUtility;
import com.lbg.test.meetingscheduler.model.MeetingFormat;

@Service
public class SchedulingServiceImpl implements SchedulingService {

	public Map<LocalDate, List<String>> processPayload(String payload) {
		// split using new line as a parameter.
		String[] lines = payload.split("\\R");
		List<MeetingFormat> bookings = SchedulingUtility.populateDto(lines);
		//SchedulingUtility.removeOverlappedMeetings(bookings);
		return SchedulingUtility.groupMeetings(bookings);
	}

}
