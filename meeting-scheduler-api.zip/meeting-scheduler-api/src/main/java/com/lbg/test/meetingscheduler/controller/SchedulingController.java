package com.lbg.test.meetingscheduler.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lbg.test.meetingscheduler.service.SchedulingService;

@RestController
public class SchedulingController {

	@Autowired
	SchedulingService service;

	@PostMapping(value = "/bookMeeting", consumes = MediaType.TEXT_PLAIN_VALUE)
	public Map<LocalDate, List<String>> bookMeeting(@RequestBody String payload) {
		return service.processPayload(payload);
	}
}
