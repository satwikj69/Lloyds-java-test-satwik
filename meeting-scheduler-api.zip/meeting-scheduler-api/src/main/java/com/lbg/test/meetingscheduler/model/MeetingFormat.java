package com.lbg.test.meetingscheduler.model;

import java.time.LocalDate;
import java.time.LocalTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MeetingFormat {

	@NonNull
	private LocalDate submissionDate;
	@NonNull
	private LocalTime submissionTime;
	@NonNull
	private String empId;
	@NonNull
	private LocalDate startDate;
	@NonNull
	private LocalTime startTime;
	private LocalTime endTime;

	public String getDetails() {
		return startTime + " " + endTime + " " + empId;
	}

}
