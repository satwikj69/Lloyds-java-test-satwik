package com.lbg.test.meetingscheduler;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.lbg.test.meetingscheduler.model.MeetingFormat;
import com.lbg.test.meetingscheduler.util.SchedulingUtility;

public class SchedulingUtilityTest {

	String[] validStub = { "0900 1800", "2016-07-18 11:17:06 EMP01 2016-07-21 09:00 2" };
	String[] invalidStub = { "0900 1800", "2016-07-18 11:17:06 EMP01 2016-07-21 08:00 2" };

	@Test
	void testPopulateDto_validStubData_notNull() {
		List<MeetingFormat> meetings = SchedulingUtility.populateDto(validStub);
		assertNotNull(meetings);
	}

	@Test
	void testPopulateDto_validStubData_validEmpId() {
		List<MeetingFormat> meetings = SchedulingUtility.populateDto(validStub);
		assertEquals("EMP01", meetings.get(0).getEmpId());
	}

	@Test
	void testPopulateDto_invalidStubData_emptyResponse() {
		List<MeetingFormat> meetings = SchedulingUtility.populateDto(invalidStub);
		assertEquals(0, meetings.size());
	}

}
