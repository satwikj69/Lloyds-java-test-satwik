package com.lbg.test.meetingscheduler;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.lbg.test.meetingscheduler.controller.SchedulingController;
import com.lbg.test.meetingscheduler.service.SchedulingService;

@SpringBootTest
class MeetingSchedulerApplicationTests {

	@Autowired
	SchedulingController controller;
	
	@Autowired
	SchedulingService service;

	@Test
	void contextLoads() {
		assertThat(controller).isNotNull();
		assertThat(service).isNotNull();
	}

}
