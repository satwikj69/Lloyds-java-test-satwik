package com.lbg.test.meetingscheduler;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.lbg.test.meetingscheduler.service.SchedulingService;

@AutoConfigureMockMvc
@SpringBootTest
public class SchedulingControllerTest {

	@MockBean
	SchedulingService service;

	@Autowired
	MockMvc mockMvc;

	@Test
	public void testBookMeeting() {
		Mockito.when(service.processPayload("PAYLOAD")).thenReturn(new HashMap<LocalDate, List<String>>());
	}

}
